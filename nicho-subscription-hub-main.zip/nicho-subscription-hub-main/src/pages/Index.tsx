
import React from 'react';
import Hero from '../components/Hero';
import SubscriptionTiers from '../components/SubscriptionTiers';
import PremiumTicket from '../components/PremiumTicket';
import MeetGreetBooking from '../components/MeetGreetBooking';
import ContactSection from '../components/ContactSection';

const Index = () => {
  return (
    <div className="min-h-screen bg-gray-900">
      <Hero />
      <SubscriptionTiers />
      <PremiumTicket />
      <MeetGreetBooking />
      <ContactSection />
    </div>
  );
};

export default Index;
