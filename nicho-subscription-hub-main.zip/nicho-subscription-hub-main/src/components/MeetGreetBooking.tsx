
import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Users, Send } from 'lucide-react';

const MeetGreetBooking = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [guestCount, setGuestCount] = useState(1);
  const [message, setMessage] = useState('');

  const availableDates = [
    { date: '2024-07-15', label: 'July 15th - Los Angeles' },
    { date: '2024-07-22', label: 'July 22nd - New York' },
    { date: '2024-07-29', label: 'July 29th - Miami' },
    { date: '2024-08-05', label: 'August 5th - Chicago' }
  ];

  const timeSlots = [
    '10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle booking submission
    console.log('Booking submitted:', { selectedDate, selectedTime, guestCount, message });
  };

  return (
    <section className="py-20 px-4 bg-gradient-to-br from-gray-900 to-gray-800">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent animate-fade-in">
            Book Your Meet & Greet
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto animate-fade-in delay-100">
            Reserve your exclusive one-on-one time with Ivan. Limited spots available!
          </p>
        </div>
        
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-8 shadow-2xl animate-fade-in delay-200 hover:shadow-3xl transition-all duration-300">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Date Selection */}
            <div className="animate-fade-in delay-300">
              <label className="flex items-center text-lg font-semibold text-white mb-4">
                <Calendar className="w-5 h-5 mr-2 animate-pulse" />
                Select Date & Location
              </label>
              <div className="grid md:grid-cols-2 gap-4">
                {availableDates.map((dateOption, index) => (
                  <label key={dateOption.date} className="cursor-pointer animate-fade-in" style={{ animationDelay: `${300 + (index * 100)}ms` }}>
                    <input
                      type="radio"
                      name="date"
                      value={dateOption.date}
                      checked={selectedDate === dateOption.date}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="sr-only"
                    />
                    <div className={`p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                      selectedDate === dateOption.date 
                        ? 'border-purple-500 bg-purple-500/20 animate-pulse' 
                        : 'border-gray-600 hover:border-gray-500'
                    }`}>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 text-purple-400 mr-2" />
                        <span className="text-white">{dateOption.label}</span>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Time Selection */}
            <div className="animate-fade-in delay-400">
              <label className="flex items-center text-lg font-semibold text-white mb-4">
                <Clock className="w-5 h-5 mr-2 animate-pulse delay-100" />
                Select Time
              </label>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {timeSlots.map((time, index) => (
                  <label key={time} className="cursor-pointer animate-fade-in" style={{ animationDelay: `${400 + (index * 50)}ms` }}>
                    <input
                      type="radio"
                      name="time"
                      value={time}
                      checked={selectedTime === time}
                      onChange={(e) => setSelectedTime(e.target.value)}
                      className="sr-only"
                    />
                    <div className={`p-3 rounded-lg text-center border-2 transition-all duration-300 hover:scale-105 ${
                      selectedTime === time 
                        ? 'border-blue-500 bg-blue-500/20 text-blue-300 animate-pulse' 
                        : 'border-gray-600 text-gray-300 hover:border-gray-500'
                    }`}>
                      {time}
                    </div>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Guest Count */}
            <div className="animate-fade-in delay-500">
              <label className="flex items-center text-lg font-semibold text-white mb-4">
                <Users className="w-5 h-5 mr-2 animate-pulse delay-200" />
                Number of Guests
              </label>
              <select
                value={guestCount}
                onChange={(e) => setGuestCount(Number(e.target.value))}
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 hover:scale-105 focus:scale-105"
              >
                {[1, 2, 3, 4, 5].map((num) => (
                  <option key={num} value={num}>
                    {num} {num === 1 ? 'Guest' : 'Guests'}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Special Message */}
            <div className="animate-fade-in delay-600">
              <label className="flex items-center text-lg font-semibold text-white mb-4">
                <Send className="w-5 h-5 mr-2 animate-pulse delay-300" />
                Special Message (Optional)
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell Ivan something special about this meet & greet..."
                rows={4}
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none transition-all duration-300 hover:scale-105 focus:scale-105"
              />
            </div>
            
            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 px-8 rounded-xl text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl animate-fade-in delay-700 animate-bounce"
            >
              Reserve Your Spot
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default MeetGreetBooking;
