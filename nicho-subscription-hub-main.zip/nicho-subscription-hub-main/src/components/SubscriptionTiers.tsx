import React from 'react';
import { Check, Crown, Star, Heart } from 'lucide-react';

const SubscriptionTiers = () => {
  const tiers = [
    {
      name: "Fan",
      price: "$109.99",
      period: "monthly",
      icon: <Heart className="w-6 h-6" />,
      gradient: "from-pink-500 to-rose-500",
      features: [
        "Exclusive photos and updates",
        "Monthly live streams",
        "Community access",
        "Priority support"
      ]
    },
    {
      name: "VIP",
      price: "$124.99",
      period: "monthly",
      icon: <Star className="w-6 h-6" />,
      gradient: "from-purple-500 to-indigo-500",
      popular: true,
      features: [
        "Everything in Fan tier",
        "Weekly exclusive content",
        "Direct message access",
        "Meet & greet reservations",
        "Behind-the-scenes content"
      ]
    },
    {
      name: "Elite",
      price: "$149.99",
      period: "monthly",
      icon: <Crown className="w-6 h-6" />,
      gradient: "from-yellow-500 to-orange-500",
      features: [
        "Everything in VIP tier",
        "Personal video messages",
        "Priority meet & greet booking",
        "Exclusive merchandise",
        "One-on-one video calls",
        "Custom content requests"
      ]
    }
  ];

  return (
    <section className="py-20 px-4 bg-gray-900">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent animate-fade-in">
            Choose Your Access Level
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto animate-fade-in delay-100">
            Get closer to Ivan with exclusive content, personal interactions, and unforgettable experiences
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {tiers.map((tier, index) => (
            <div 
              key={index} 
              className={`relative bg-gray-800 rounded-2xl p-8 transition-all duration-500 hover:scale-105 hover:shadow-2xl animate-fade-in ${tier.popular ? 'ring-2 ring-purple-500 transform scale-105 animate-bounce' : ''}`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              {tier.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 animate-pulse">
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm font-bold">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-8">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r ${tier.gradient} mb-4 animate-pulse`} style={{ animationDelay: `${index * 100}ms` }}>
                  {tier.icon}
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{tier.name}</h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-white">{tier.price}</span>
                  <span className="text-gray-400">/{tier.period}</span>
                </div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {tier.features.map((feature, featureIndex) => (
                  <li 
                    key={featureIndex} 
                    className="flex items-center text-gray-300 animate-fade-in"
                    style={{ animationDelay: `${(index * 200) + (featureIndex * 100)}ms` }}
                  >
                    <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0 animate-bounce" style={{ animationDelay: `${featureIndex * 200}ms` }} />
                    {feature}
                  </li>
                ))}
              </ul>
              
              <button className={`w-full bg-gradient-to-r ${tier.gradient} hover:opacity-90 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg animate-fade-in`} style={{ animationDelay: `${(index * 200) + 500}ms` }}>
                Subscribe Now
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SubscriptionTiers;
