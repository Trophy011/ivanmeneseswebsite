
import React from 'react';
import { MessageCircle, Send, Phone, Mail } from 'lucide-react';

const ContactSection = () => {
  return (
    <section className="py-20 px-4 bg-gray-900">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent animate-fade-in">
          Get in Touch
        </h2>
        <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto animate-fade-in delay-100">
          Have questions about subscriptions or need help with booking? Reach out directly!
        </p>
        
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Telegram Contact */}
          <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-sm rounded-2xl p-8 border border-blue-500/20 animate-fade-in delay-200 hover:scale-105 transition-all duration-300">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <MessageCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Telegram</h3>
              <p className="text-gray-400 mb-6">Get instant responses and exclusive updates</p>
              <a
                href="https://t.me/ivan_nicho"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
              >
                <Send className="w-5 h-5 mr-2" />
                Message on Telegram
              </a>
            </div>
          </div>
          
          {/* Support Contact */}
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20 animate-fade-in delay-300 hover:scale-105 transition-all duration-300">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse delay-500">
                <Mail className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Support</h3>
              <p className="text-gray-400 mb-6">Need help with your subscription or booking?</p>
              <button className="inline-flex items-center bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg">
                <Phone className="w-5 h-5 mr-2" />
                Contact Support
              </button>
            </div>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 animate-fade-in delay-400">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center animate-bounce delay-100">
              <div className="text-3xl font-bold text-white mb-2">2min</div>
              <div className="text-gray-400">Response Time</div>
            </div>
            <div className="text-center animate-bounce delay-200">
              <div className="text-3xl font-bold text-white mb-2">24/7</div>
              <div className="text-gray-400">Available</div>
            </div>
            <div className="text-center animate-bounce delay-300">
              <div className="text-3xl font-bold text-white mb-2">100%</div>
              <div className="text-gray-400">Satisfaction</div>
            </div>
            <div className="text-center animate-bounce delay-500">
              <div className="text-3xl font-bold text-white mb-2">1k+</div>
              <div className="text-gray-400">Happy Fans</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
