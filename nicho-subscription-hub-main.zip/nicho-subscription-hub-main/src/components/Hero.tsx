import React from 'react';
import { Star, Heart, Users } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-64 h-64 bg-purple-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        {/* Profile Image */}
        <div className="mb-8 animate-fade-in">
          <div className="w-64 h-64 mx-auto relative">
            <img 
              src="/lovable-uploads/38b27644-f9da-49e0-8955-372b3cdfd8b6.png" 
              alt="Ivan Nicholo Meneses"
              className="w-full h-full object-cover rounded-full border-4 border-purple-400 shadow-2xl hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute -top-2 -right-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full p-2 animate-bounce">
              <Star className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
        
        {/* Main Title */}
        <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent animate-fade-in delay-200">
          Ivan Nicholo Meneses
        </h1>
        
        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto animate-fade-in delay-300">
          Exclusive access to meet and greet experiences, behind-the-scenes content, and personal interactions
        </p>
        
        {/* Stats */}
        <div className="flex justify-center space-x-8 mb-12">
          <div className="text-center animate-fade-in delay-400 hover:scale-110 transition-transform duration-300">
            <div className="flex items-center justify-center mb-2">
              <Heart className="w-6 h-6 text-red-400 mr-2 animate-pulse" />
              <span className="text-3xl font-bold text-white">2.5K</span>
            </div>
            <p className="text-gray-400">Subscribers</p>
          </div>
          <div className="text-center animate-fade-in delay-500 hover:scale-110 transition-transform duration-300">
            <div className="flex items-center justify-center mb-2">
              <Users className="w-6 h-6 text-blue-400 mr-2 animate-pulse delay-200" />
              <span className="text-3xl font-bold text-white">156</span>
            </div>
            <p className="text-gray-400">Meet & Greets</p>
          </div>
          <div className="text-center animate-fade-in delay-700 hover:scale-110 transition-transform duration-300">
            <div className="flex items-center justify-center mb-2">
              <Star className="w-6 h-6 text-yellow-400 mr-2 animate-pulse delay-300" />
              <span className="text-3xl font-bold text-white">4.9</span>
            </div>
            <p className="text-gray-400">Rating</p>
          </div>
        </div>
        
        {/* CTA Button */}
        <button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl animate-fade-in delay-700 animate-bounce">
          Join Exclusive Community
        </button>
      </div>
    </section>
  );
};

export default Hero;
